import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useWindow } from "@/components/lib/useWindow";
import usePermissions from "@/components/lib/usePermissions";
import { useContextoVisual } from "@/components/lib/useContextoVisual";
import { useUser } from "@/components/lib/UserContext";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";
import VisualizadorUniversalEntidadeV24 from "@/components/cadastros/VisualizadorUniversalEntidadeV24";
import { Zap, Code, Settings, Package, Link2, Cloud, MessageCircle, Bell } from "lucide-react";
import CountBadgeSimplificado from "@/components/cadastros/CountBadgeSimplificado";

import ApiExternaForm from "@/components/cadastros/ApiExternaForm";
import ChatbotCanalForm from "@/components/cadastros/ChatbotCanalForm";
import ChatbotIntentForm from "@/components/cadastros/ChatbotIntentForm";
import GatewayPagamentoForm from "@/components/cadastros/GatewayPagamentoForm";
import JobAgendadoForm from "@/components/cadastros/JobAgendadoForm";
import WebhookForm from "@/components/cadastros/WebhookForm";
import ConfiguracaoNFeForm from "@/components/cadastros/ConfiguracaoNFeForm";
import EventoNotificacaoForm from "@/components/cadastros/EventoNotificacaoForm";

function filterTiles(tiles, searchTerm) {
  const q = String(searchTerm || "").trim().toLowerCase();
  if (!q) return tiles;
  return tiles.filter(({ k, t }) => `${k} ${t}`.toLowerCase().includes(q));
}

export default function Bloco6Tecnologia({ allCounts, isLoading, searchTerm = "" }) {
  const { openWindow } = useWindow();
  const { hasPermission } = usePermissions();
  const { empresaAtual, grupoAtual } = useContextoVisual();
  const { user } = useUser();
  const { toast } = useToast();
  const groupId = grupoAtual?.id || empresaAtual?.group_id || empresaAtual?.grupo_id || null;
  const empresaId = empresaAtual?.id || null;
  const contextoValido = Boolean(groupId || empresaId);

  const registrarAuditoria = async (entidade, acao, sucesso = true) => {
    try {
      await base44.entities.AuditLog.create({
        usuario_id: user?.id,
        usuario: user?.full_name || user?.email || "Usuario",
        acao,
        modulo: "Cadastros",
        entidade,
        tipo_auditoria: sucesso ? "acesso" : "seguranca",
        descricao: `${acao} em cadastro de tecnologia, IA e parametros: ${entidade}`,
        empresa_id: empresaId,
        group_id: groupId,
        grupo_id: groupId,
        dados_novos: { bloco: "Tecnologia, IA & Parametros", entidade },
        data_hora: new Date().toISOString(),
        sucesso,
      });
    } catch (_) {}
  };

  const openList = (entidade, titulo, Icon, campos, FormComp) => () => {
    if (!contextoValido) {
      toast({
        title: "Selecione grupo ou empresa",
        description: "Cadastros de tecnologia precisam de contexto ativo para abrir.",
        variant: "destructive",
      });
      registrarAuditoria(entidade, "Bloqueio sem contexto", false);
      return;
    }
    if (!canViewEntity(entidade)) {
      toast({
        title: "Acesso negado",
        description: "Seu perfil nao possui permissao para visualizar este cadastro.",
        variant: "destructive",
      });
      registrarAuditoria(entidade, "Bloqueio por permissao", false);
      return;
    }
    registrarAuditoria(entidade, "Visualizacao");
    openWindow(
      VisualizadorUniversalEntidadeV24,
      { nomeEntidade: entidade, tituloDisplay: titulo, icone: Icon, camposPrincipais: campos, componenteEdicao: FormComp, windowMode: true },
      { title: titulo, width: 1400, height: 800 }
    );
  };

  const tiles = [
    { k: 'ApiExterna',         t: 'APIs Externas',          i: Code,          c: ['nome','nome_integracao','url_base','tipo_api'],   f: ApiExternaForm },
    { k: 'ChatbotCanal',       t: 'Canais Chatbot',         i: MessageCircle, c: ['nome','nome_canal','tipo_canal','ativo'],          f: ChatbotCanalForm },
    { k: 'ChatbotIntent',      t: 'Intents Chatbot',        i: Zap,           c: ['nome','nome_intent','descricao','ativo'],          f: ChatbotIntentForm },
    { k: 'GatewayPagamento',   t: 'Gateways de Pagamento',  i: Package,       c: ['nome','provedor','ambiente','ativo'],              f: GatewayPagamentoForm },
    { k: 'JobAgendado',        t: 'Jobs Agendados',         i: Cloud,         c: ['nome','nome_job','frequencia','tipo_job'],         f: JobAgendadoForm },
    { k: 'Webhook',            t: 'Webhooks',               i: Link2,         c: ['nome','nome_webhook','evento_gatilho','ativo'],    f: WebhookForm },
    { k: 'ConfiguracaoNFe',    t: 'Configurações NF-e',     i: Settings,      c: ['nome','provedor','ambiente','ativo'],              f: ConfiguracaoNFeForm },
    { k: 'EventoNotificacao',   t: 'Eventos & Notificações', i: Bell,          c: ['nome_evento','tipo_evento','prioridade','ativo'],  f: EventoNotificacaoForm },
  ];
  const filteredTiles = filterTiles(tiles, searchTerm);
  const canViewEntity = (entidade) =>
    hasPermission("Cadastros", entidade, "visualizar") ||
    hasPermission("Cadastros", null, "visualizar") ||
    hasPermission("Sistema", entidade, "visualizar") ||
    hasPermission("Sistema", null, "visualizar");

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      <Card className="rounded-sm shadow-sm border bg-white/80 backdrop-blur">
        <CardHeader className="bg-gradient-to-r from-indigo-50 to-violet-50 border-b rounded-t-sm">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="w-5 h-5 text-indigo-700"/> Tecnologia, IA & Parâmetros
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 text-sm text-slate-600">
          {contextoValido ? "Total consolidado do grupo/empresa." : "Selecione grupo ou empresa para abrir tecnologia, IA e parametros."}
        </CardContent>
      </Card>

      {filteredTiles.map(({ k, t, i: Icon, c, f: FormComp }) => (
        <Card 
          key={k} 
          className="rounded-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-150 cursor-pointer group border"
          onClick={openList(k, t, Icon, c, FormComp)}
          data-permission={`Cadastros.${k}.visualizar`}
          data-action={`Cadastros.${k}.abrir`}
          data-context-required="group-or-company"
        >
          <CardHeader className="bg-gradient-to-r from-slate-50 to-white border-b pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-slate-700">
                <div className="p-1.5 rounded-sm bg-indigo-50 group-hover:bg-indigo-100 transition-colors">
                  <Icon className="w-4 h-4 text-indigo-600" />
                </div>
                {t}
                <CountBadgeSimplificado entities={[k]} allCounts={allCounts} isLoading={isLoading} />
              </CardTitle>
              <Button 
                size="sm" 
                className="bg-blue-600 hover:bg-blue-700 rounded-sm text-xs h-7"
                onClick={(e) => { e.stopPropagation(); openList(k, t, Icon, c, FormComp)(); }}
                disabled={!contextoValido || !canViewEntity(k)}
                data-permission={`Cadastros.${k}.visualizar`}
                data-action={`Cadastros.${k}.abrir`}
                data-context-required="group-or-company"
              >
                Abrir
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-3 text-xs text-slate-500">
            Clique para listar, criar e editar em janela flutuante.
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
